export class Credential {
    poolHandle?: number;
    doctorDid?: string;
    doctorWallet?: number;
    prescriptionSchemaId?: string;
    prescriptionSchema?: object;
    seqNo?: number
}