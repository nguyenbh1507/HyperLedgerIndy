import Contract from '../models/contract';
import BaseCtrl from './base';

export default class ContractCtrl extends BaseCtrl {
  model = Contract;
}
