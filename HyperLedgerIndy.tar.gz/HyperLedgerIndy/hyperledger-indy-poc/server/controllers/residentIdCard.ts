import ResidentIdCard from '../models/residentIdCard';
import BaseCtrl from './base';

export default class ResidentIdCardCtrl extends BaseCtrl {
  model = ResidentIdCard;
}
