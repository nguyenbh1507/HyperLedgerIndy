import IdCardSchema from '../models/idCardSchema';
import BaseCtrl from './base';

export default class SchemaCtrl extends BaseCtrl {
  model = IdCardSchema;
}
