import CredentialDefinition from '../models/credentialDefinition';
import BaseCtrl from './base';

export default class CredentialDefinitionCtrl extends BaseCtrl {
  model = CredentialDefinition;
}
